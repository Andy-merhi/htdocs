<?php
$con = mysqli_connect('localhost', 'root', '', 'phones') 

or die("Unable to connect");
?>